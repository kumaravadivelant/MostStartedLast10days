﻿
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StarredRepos = () => {
    const [repos, setRepos] = useState([]);
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);

    const fetchRepos = async (pageNumber) => {
        setLoading(true);
        const date = new Date();
        date.setDate(date.getDate() - 10);
        const dateString = date.toISOString().split('T')[0];

        try {
            const url = `https://api.github.com/search/repositories?q=created:>${dateString}&sort=stars&order=desc&page=${pageNumber}&per_page=30`;
            const res = await axios.get(url);
            setRepos(prevRepos => [...prevRepos, ...res.data.items]);
        } catch (error) {
            console.error("Error fetching repos:", error);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchRepos(page);
    }, [page]);

    const handleScroll = () => {
        if (
            window.innerHeight + document.documentElement.scrollTop >=
            document.documentElement.offsetHeight - 50 &&
            !loading
        ) {
            setPage(prevPage => prevPage + 1);
        }
    };

    useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, [loading]);

    return (
        <div style={{
            maxWidth: '480px',
            margin: '0 auto',
            padding: '16px',
            paddingBottom: '80px', 
            backgroundColor: '#f8f8f8',
            minHeight: '100vh'
        }}>
            <h2 style={{
                textAlign: 'center',
                margin: '20px 0 30px',
                fontSize: '20px',
                fontWeight: '600',
                color: '#333'
            }}>
                Most Starred GitHub Repos (Last 10 Days)
            </h2>

            {repos.map(repo => (
                <div key={repo.id} style={{
                    backgroundColor: '#fff',
                    borderRadius: '12px',
                    padding: '16px',
                    marginBottom: '12px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
                }}>
                    <h3 style={{
                        fontSize: '16px',
                        fontWeight: '600',
                        marginBottom: '8px',
                        color: '#333'
                    }}>{repo.name}</h3>

                    {repo.description && (
                        <p style={{
                            fontSize: '14px',
                            color: '#666',
                            marginBottom: '12px',
                            lineHeight: '1.4'
                        }}>{repo.description}</p>
                    )}

                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                            <img
                                src={repo.owner.avatar_url}
                                alt={repo.owner.login}
                                style={{
                                    width: '24px',
                                    height: '24px',
                                    borderRadius: '50%',
                                    marginRight: '8px'
                                }}
                            />
                            <span style={{
                                fontSize: '14px',
                                color: '#666'
                            }}>{repo.owner.login}</span>
                        </div>
                        <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            color: '#333',
                            fontWeight: '600',
                            fontSize: '14px'
                        }}>
                            {'\u2605'} {(repo.stargazers_count / 1000).toFixed(1)}k
                        </div>
                    </div>
                </div>
            ))}

            {loading && (
                <div style={{ textAlign: 'center', padding: '20px', color: '#666' }}>
                    Loading more repositories...
                </div>
            )}

            {}
            <div style={{
                position: 'fixed',
                bottom: '0',
                left: '0',
                right: '0',
                backgroundColor: '#fff',
                borderTop: '1px solid #eee',
                display: 'flex',
                justifyContent: 'center',
                padding: '12px 0',
                maxWidth: '480px',
                margin: '0 auto'
            }}>
                <div style={{
                    display: 'flex',
                    justifyContent: 'space-around',
                    width: '100%',
                    maxWidth: '480px',
                    padding: '0 16px'
                }}>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        color: '#007AFF'
                    }}>
                        <div style={{ fontSize: '20px' }}>{'\u2605'}</div>
                        <div style={{ fontSize: '12px', marginTop: '4px' }}>Trending</div>
                    </div>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        color: '#888'
                    }}>
                        <div style={{ fontSize: '20px' }}>{'\u2699'}</div>

                        <div style={{ fontSize: '12px', marginTop: '4px' }}>Settings</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StarredRepos;