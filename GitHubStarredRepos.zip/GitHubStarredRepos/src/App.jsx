import React from 'react';
import StarredRepos from './StarredRepos';

function App() {
    return (
        <div className="App">
            <StarredRepos />
        </div>
    );
}
export default App;
